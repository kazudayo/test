---
title: Customer Journey Map
number: 2

allStage: {
   stage1 : "ここを書き換え1",
   stage2 : "ここを書き換え2",
   stage3 : "ここを書き換え3",
   stage4 : "ここを書き換え4",
}

detail: {
stage1: {
 Touchpoint: "・ここを書き換え1",
 Action: "・ここを書き換え",
 Thinking: "「ここを書き換え」",
 },
stage2: {
 Touchpoint: "・ここを書き換え2",
 Action: "・ここを書き換え",
 Thinking: "「ここを書き換え」",
 },
stage3: {
 Touchpoint: "・ここを書き換え3",
 Action: "・ここを書き換え",
 Thinking: "「ここを書き換え」",
 },
stage4: {
 Touchpoint: "・ここを書き換え4",
 Action: "・ここを書き換え",
 Thinking: "「ここを書き換え」",
 },
}

experiencePoint : [50,50,50,50]

allopo: {
Opportunitie1: "ここを書き換え1",
Opportunitie2: "ここを書き換え2",
Opportunitie3: "ここを書き換え3",
Opportunitie4: "ここを書き換え4",
}

---