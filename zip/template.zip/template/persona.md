---
title: Persona
number: 1

img: hammer.png

name: ここに名前を入力

basic: 基本情報
basiclist:
- info: "年齢・性別：ここを書き換え"
- info: "住まい：ここを書き換え"
- info: "家族：ここを書き換え"
- info: "趣味：ここを書き換え"
- info: "出身：ここを書き換え"
- info: "職業：ここを書き換え"

keyword: ここにキーワードを入力

feature: 特徴
featureContents:
- info: "性格：ここを書き換え"

- info: "情報源：ここを書き換え"

- info: "購買行動：ここを書き換え"

underContent:
- info: "目標\nここを書き換え"

- info: "音楽
\n好きなジャンル：ここを書き換え
\nリスニング環境：ここを書き換え
\n行動：ここを書き換え
"
- info: "楽器
\n愛用する楽器：ここを書き換え
\n楽器歴：ここを書き換え
\n行動・楽器との関わり：ここを書き換え
"
- info: "デジタル
\nモバイル：ここを書き換え
\nPC・タブレット：ここを書き換え
\n家電：ここを書き換え
\n行動：ここを書き換え
"
---