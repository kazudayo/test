---
title: Value Proposition Canvas
number: 3

# ペルソナの画像 content/img/に画像を入れてください
img: hammer.png

gainsTitle: Gains
# ペルソナの利得
gains: "・ここを書き換え"

painsTitle: Pains
# ペルソナの悩み
pains: "・ここを書き換え"

CustomerJobsTitle: "Customer\nJobs"
# ペルソナが解決したい課題
CustomerJobs: "・ここを書き換え"

gainCreatorsTitle: Gain Creators
# ペルソナの利得をもたらすもの
gainCreators: "・ここを書き換え"

painRelieversTitle: Pain Relievers
# ペルソナの悩みを取り除くもの
painRelievers: "・ここを書き換え"

# 製品・サービスの名前
serviceName: "ここを書き換え"

productsServicesTitle: "Products\n&Services"
# 製品やサービスの詳細
productsServices: "・ここを書き換え"
---